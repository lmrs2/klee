#include <termios.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>

extern void klee_ignore_undefined(void *addr, size_t nbytes);
int main() {

	return isatty(0);
	// int ret;
	// klee_ignore_undefined(&ret, sizeof(ret));
	// return ret;
}