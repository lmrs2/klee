// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O0 -Xclang -disable-O0-optnone select.c
// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O3                             select.c

// ../installs/klee/build/bin/klee -only-output-states-covering-new -only-replay-seeds -only-seed -libc=uclibc -posix-runtime -seed-file=klee_in/test000001.ktest select.bc
#include <stdio.h>
#include <klee/klee.h>

int aselect(int x) {
	int b = x == 0 ? 4 : 5;
	if (b == 4)
		printf("== 4\n");
	else if (b == 5)
		printf("== 5\n");
	else
		printf("other\n");
	return 0;
}

int main() {
	int a;
	klee_make_symbolic(&a, sizeof(a), "a");
	return aselect(a);
}