// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O0 -Xclang -disable-O0-optnone if_statements.c
// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O3                             if_statements.c


// ../installs/klee/build/bin/klee -only-output-states-covering-new -only-replay-seeds -only-seed -libc=uclibc -posix-runtime -seed-file=klee_in/test000001.ktest if_statements.bc
#include <stdio.h>
#include <klee/klee.h>

int if_statements(int x) {
	if (x == 0)
		printf("== 0\n");
	else if (x < 0)
		printf("< 0\n");
	else {
		printf("> 0\n");

		if (x == 1)
			printf("== 1\n");

		if (x > 10)
			printf("> 10\n");
		else 
			printf("< 10\n");
	}

	return 0;
}

int main() {
	int a;
	klee_make_symbolic(&a, sizeof(a), "a");
	return if_statements(a);
}