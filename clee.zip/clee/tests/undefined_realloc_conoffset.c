// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O0 -Xclang -disable-O0-optnone malloc.c
// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O3                             malloc.c
// -fsanitize=memory

// ../installs/klee/build/bin/klee -only-output-states-covering-new -only-replay-seeds -only-seed -libc=uclibc -posix-runtime -seed-file=klee_in/test000001.ktest select.bc
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <klee/klee.h>


int arealloc(size_t x) {
	
	unsigned char * buffer = (unsigned char*) malloc(x);
	buffer = (unsigned char*)realloc(buffer, 10);
	if (buffer && buffer[7] == 0xAB)
		printf("error\n");
	return 0;
}

int main() {
	size_t a;
	klee_make_symbolic(&a, sizeof(a), "a");
	return arealloc(a);
}
