// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O0 -Xclang -disable-O0-optnone malloc.c
// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O3                             malloc.c
// -fsanitize=memory

// ../installs/klee/build/bin/klee -only-output-states-covering-new -only-replay-seeds -only-seed -libc=uclibc -posix-runtime -seed-file=klee_in/test000001.ktest select.bc
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <klee/klee.h>


int amalloc(size_t x, size_t y) {
	
	//if (!(y < 256)) return -1;
	unsigned char * buffer = (unsigned char*) malloc(x);
	
	// if (buffer && x > 0) {
	// 	buffer[0] = 1;
	// 	if (buffer[y] == 0xAB)
	// 		printf("gotcha\n"); // gives out-of-bound and non-init'ed mem
	// }

	// if (buffer && x > 0) {
	// 	buffer[0] = 1;
	// 	buffer[1] = 2;
	// 	buffer[x-1] = x-1;
	// 	if (y<x && buffer[y] == 0xAB)
	// 		printf("gotcha\n"); // gives non-init'ed mem
	// }

	//if (buffer && y<x && buffer[y] == 0xAB) printf("error\n"); //gives non-init'ed mem
	//if (buffer && y < x) return buffer[y]; // gives non-init'ed mem
	

	// if (buffer && x > 0) {
	// 	memset(buffer, 4, x-1);
	// 	return buffer[y]; // gives out-of-bound and non-init'ed
	// } 


	// if (buffer && x > 0) {
	// 	return buffer[x-1];
	// } // gives non-init
	
	if (buffer && x > 2 && y < x) {
		// for (size_t i=0; i<x-1; ++i)
		// 	buffer[i] = 18;
		memset(buffer, 10, x-2);
		buffer[x-2] = 18;
		return buffer[y];
	}
	
	

		//
	return 0;
}

int main() {
	size_t a, b;
	klee_make_symbolic(&a, sizeof(a), "a");
	klee_make_symbolic(&b, sizeof(b), "b");
	return amalloc(a,b);
}
