int main() {
	printf("%p\n", malloc(0));
	return 0;
}