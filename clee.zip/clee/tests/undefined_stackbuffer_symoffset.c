// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O0 -Xclang -disable-O0-optnone malloc.c
// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O3                             malloc.c
// -fsanitize=memory

// ../installs/klee/build/bin/klee -only-output-states-covering-new -only-replay-seeds -only-seed -libc=uclibc -posix-runtime -seed-file=klee_in/test000001.ktest select.bc

// RESULT: find non-init'ed mem
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <klee/klee.h>


int astack(size_t x) {
	
	unsigned char buffer[10];
	memset(buffer, 0, 8);
	buffer[9] = 1;
	//if (buffer[x] == 0xAB) // finds both
	if (x<10 && buffer[x] == 0xAB) // finds non-init mem
		printf("gotcha\n");
	return 0;
}

int main() {
	size_t a;
	klee_make_symbolic(&a, sizeof(a), "a");
	return astack(a);
}
