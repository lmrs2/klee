// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O0 -Xclang -disable-O0-optnone switch_statements.c
// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O3                             switch_statements.c

// ../installs/klee/build/bin/klee -only-output-states-covering-new -only-replay-seeds -only-seed -libc=uclibc -posix-runtime -seed-file=klee_in/test000001.ktest switch_statements.bc
#include <stdio.h>
#include <klee/klee.h>

int switch_statements(int x) {
	switch(x) {
		case 0:
			printf("== 0\n");
			break;
		case 1:
			printf("== 1\n");
			break;
		case 10:
			printf("== 10\n");
			break;
		default:
			printf("default (0)\n");
			break;
	}

	return 0;
}

int main() {
	int a;
	klee_make_symbolic(&a, sizeof(a), "a");
	return switch_statements(a);
}