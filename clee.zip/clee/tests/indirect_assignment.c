// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O0 -Xclang -disable-O0-optnone indirect_assignment.c
// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O3                             indirect_assignment.c

// ../installs/klee/build/bin/klee -only-output-states-covering-new -only-replay-seeds -only-seed -libc=uclibc -posix-runtime -seed-file=klee_in/test000001.ktest indirect_assignment.bc
#include <stdio.h>
#include <klee/klee.h>

int indirect_assignment(int x) {
	int r = 0;
	if (x == 0)
		r = 1;
	else if (x < 0)
		r = 2;
	else
		r = 3;

	switch (r) {
		case 1:
			printf("== 1\n");
			break;
		case 2:
			printf("== 2\n");
			break;
		case 3:
			printf("== 3\n");
			break;
		default:
			printf("default\n"); // Note: not reachable
			break;
	}
	return 0;
}

int main() {
	int a;
	klee_make_symbolic(&a, sizeof(a), "a");
	return indirect_assignment(a);
}