// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O0 -Xclang -disable-O0-optnone malloc.c
// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O3                             malloc.c
// -fsanitize=memory

// ../installs/klee/build/bin/klee -only-output-states-covering-new -only-replay-seeds -only-seed -libc=uclibc -posix-runtime -seed-file=klee_in/test000001.ktest select.bc
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <klee/klee.h>


int arealloc(size_t x) {
	
	unsigned char * buffer = (unsigned char*) malloc(x);
	if (!buffer) return 1;
	buffer = (unsigned char*)realloc(buffer, 128);
	if (buffer && buffer[x-1] == 0xAB)
	// if (buffer && x > 0 && buffer[x-1] == 0xAB) out-of-bound
		printf("error\n");

	return 0;
}

int main() {
	size_t a;
	klee_make_symbolic(&a, sizeof(a), "a");
	return arealloc(a);
}
