// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O0 -Xclang -disable-O0-optnone malloc.c
// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O3                             malloc.c
// -fsanitize=memory

// ../installs/klee/build/bin/klee -only-output-states-covering-new -only-replay-seeds -only-seed -libc=uclibc -posix-runtime -seed-file=klee_in/test000001.ktest select.bc
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <klee/klee.h>


/* 	https://clang.llvm.org/docs/AddressSanitizer.html
	https://github.com/google/sanitizers/wiki/AddressSanitizer
	-> KLEE finds them by itself

	OK: Out-of-bounds accesses to heap, stack and globals
	OK Use-after-free
	OK Use-after-return (runtime flag ASAN_OPTIONS=detect_stack_use_after_return=1)
	? Use-after-scope (clang flag -fsanitize-address-use-after-scope)
	OK: Double-free, invalid free
	Memory leaks (experimental)

	https://clang.llvm.org/docs/MemorySanitizer.html
	NA non initialized
		- copy/strcpy/memcpy
		- symbolic offset
		- realloc (symbolic and concrete offset)
		- global
		- bool

	https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html
	integer overflow. Do we need this? KLEE will catch bugs that result from an overflow anyway... but this will stop execution before bug occors
*/

volatile int *p = 0;


int amalloc(size_t x) {
	//if (x<=5) return -1;
#if 1
	//char * buffer = (char*) malloc(x+1);
	//unsigned char * buffer = (unsigned char*) malloc(6);
	unsigned char buffer[6];
	char *ptr = buffer+2;
	//if (x)
	memcpy(buffer, "hell", strlen("hell"));
	//strcpy(buffer, "hell");
	//buffer = (unsigned char*)realloc(buffer, 10);
	if (ptr[x] == 0xAB)
		printf("error\n");
	//buffer[3] = 'a';
	// // strcat(buffer, "hi");
	//if (buffer[3] == 0xAB)
	//	printf("error\n");
		//printf("value='%c'\n", buffer[3]);
	
	//free(buffer);
	// int buffer[6];
	// memcpy(buffer, "hello", 6);
	// //if (x)
	// //	free(buffer);
	// return buffer;
	#endif
	return 0;
}

int main() {
	size_t a;
	klee_make_symbolic(&a, sizeof(a), "a");
	return amalloc(a);
}

/*

int main(int argc, char** argv) {
  int* a = malloc(10*sizeof(int));
  a[5] = 0;
  if (a[argc])
    printf("xx\n");
  return 0;
}

*/