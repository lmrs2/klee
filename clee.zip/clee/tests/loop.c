// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O0 -Xclang -disable-O0-optnone loop.c
// clang-6.0 -I ../installs/klee/include/ -emit-llvm -c -g -O3                             loop.c

// ../installs/klee/build/bin/klee -only-output-states-covering-new -only-replay-seeds -only-seed -libc=uclibc -posix-runtime -seed-file=klee_in/test000001.ktest loop.bc
#include <stdio.h>
#include <klee/klee.h>

int loop(size_t x) {
	int i;
	int r = 0;
	for (i=0; i<x; ++i)
		r += i;

	if (r < 0)
		printf("catch overflow\n"); // cannot be caught. Either remove thru UB or symbolic state blowup

	return r;
}

int main() {
	size_t a;
	klee_make_symbolic(&a, sizeof(a), "a");
	return loop(a);
}